Android Final Project

Team Bald Fox

Morgan Ariss
A00989042
morganariss93@gmail.com

Mac Craig
A00991048
maccraig@gmail.com

John Tee
A00973875
johntee@gmail.com


We completed all the requirements of the project, and we included a user manual to better explain how to use the app to the best success. 

We used the database, a lot as the primary function of the app is information sharing and management. All aspects of security and loss prevention are made simpler by the app. Ideal the design and color scheme would be changed to fit each company that the app would service. The base color scheme was made as a prototype to show the apps functionality.

The app was designed and tested primarily on my Nexus 5 API 25.