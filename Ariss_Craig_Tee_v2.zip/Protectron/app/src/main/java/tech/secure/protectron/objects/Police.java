package tech.secure.protectron.objects;

/**
 * Created by maccraig on 2017-11-28.
 */

public class Police {
    private String STRNUM;
    private String STRNAM;
    private String BLDGNAM;

    public String getNum() {
        return STRNUM;
    }

    public String getName() {
        return STRNAM;
    }

    public String getBuilding() {
        return BLDGNAM;
    }
}


